import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const JardimApp());
}

class JardimApp extends StatelessWidget {
  const JardimApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jardim App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF2E7D32), // verde
        useMaterial3: true,
      ),
      home: const ServiceRequestPage(),
    );
  }
}

class ServiceRequestPage extends StatefulWidget {
  const ServiceRequestPage({super.key});

  @override
  State<ServiceRequestPage> createState() => _ServiceRequestPageState();
}

class _ServiceRequestPageState extends State<ServiceRequestPage> {
  final _formKey = GlobalKey<FormState>();

  final _nomeCtrl = TextEditingController();
  final _telefoneCtrl = TextEditingController();
  final _enderecoCtrl = TextEditingController();
  final _bairroCtrl = TextEditingController();
  final _cidadeCtrl = TextEditingController(text: 'Rondonópolis - MT');
  final _observacoesCtrl = TextEditingController();

  final _servicos = const <String>[
    'Poda de árvores',
    'Roçagem/Capina',
    'Corte de gramado',
    'Paisagismo',
    'Manutenção de jardim',
    'Irrigação',
    'Remoção de entulho verde',
  ];
  String? _servicoSelecionado;

  DateTime? _dataPreferida;
  TimeOfDay? _horaPreferida;

  bool _aceitaOrcamentoWhats = true;

  // WhatsApp do prestador (55 + DDD + número)
  static const String _waNumber = '5566999024477'; // (66) 99902-4477

  @override
  void dispose() {
    _nomeCtrl.dispose();
    _telefoneCtrl.dispose();
    _enderecoCtrl.dispose();
    _bairroCtrl.dispose();
    _cidadeCtrl.dispose();
    _observacoesCtrl.dispose();
    super.dispose();
  }

  Future<void> _selecionarData() async {
    final hoje = DateTime.now();
    final data = await showDatePicker(
      context: context,
      initialDate: _dataPreferida ?? hoje,
      firstDate: hoje,
      lastDate: DateTime(hoje.year + 1),
      helpText: 'Selecione a data preferida',
      cancelText: 'Cancelar',
      confirmText: 'OK',
    );
    if (data != null) setState(() => _dataPreferida = data);
  }

  Future<void> _selecionarHora() async {
    final hora = await showTimePicker(
      context: context,
      initialTime: _horaPreferida ?? TimeOfDay.now(),
      helpText: 'Selecione o horário preferido',
      cancelText: 'Cancelar',
      confirmText: 'OK',
    );
    if (hora != null) setState(() => _horaPreferida = hora);
  }

  String _formataDataHora() {
    final df = DateFormat('dd/MM/yyyy');
    String hf(TimeOfDay t) {
      final dt = DateTime(0, 1, 1, t.hour, t.minute);
      return DateFormat('HH:mm').format(dt);
    }

    final dataStr = _dataPreferida != null ? df.format(_dataPreferida!) : '—';
    final horaStr = _horaPreferida != null ? hf(_horaPreferida!) : '—';
    return '$dataStr às $horaStr';
  }

  String _limpaNumero(String s) => s.replaceAll(RegExp(r'[^0-9]'), '');

  Future<void> _enviarWhatsApp() async {
    if (!_formKey.currentState!.validate()) return;

    final nome = _nomeCtrl.text.trim();
    final telefone = _limpaNumero(_telefoneCtrl.text);
    final endereco = _enderecoCtrl.text.trim();
    final bairro = _bairroCtrl.text.trim();
    final cidade = _cidadeCtrl.text.trim();
    final servico = _servicoSelecionado ?? '—';
    final dataHora = _formataDataHora();
    final obs = _observacoesCtrl.text.trim();

    final mensagem = '''
Olá! Quero solicitar um serviço de jardinagem.

* Nome: $nome
* Telefone: ${telefone.isEmpty ? '—' : telefone}
* Serviço: $servico
* Endereço: $endereco
* Bairro: $bairro
* Cidade: $cidade
* Data/Horário preferidos: $dataHora
* Observações: ${obs.isEmpty ? '—' : obs}

Autorizo orçamento e contato por WhatsApp: ${_aceitaOrcamentoWhats ? 'SIM' : 'NÃO'}
''';

    final uri = Uri.parse(
      'https://wa.me/$_waNumber?text=${Uri.encodeComponent(mensagem)}',
    );

    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Não consegui abrir o WhatsApp. Verifique se está instalado.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final pad = EdgeInsets.symmetric(
      horizontal: 16,
      vertical: MediaQuery.of(context).size.width > 600 ? 12 : 8,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Jardim App'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: pad,
            children: [
              const _SectionTitle('Dados do cliente'),
              TextFormField(
                controller: _nomeCtrl,
                decoration: const InputDecoration(
                  labelText: 'Nome completo *',
                  prefixIcon: Icon(Icons.person_outline),
                ),
                textCapitalization: TextCapitalization.words,
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Informe o nome' : null,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _telefoneCtrl,
                decoration: const InputDecoration(
                  labelText: 'Telefone (opcional)',
                  hintText: '(66) 9 9902-4477',
                  prefixIcon: Icon(Icons.phone_outlined),
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 16),

              const _SectionTitle('Local do serviço'),
              TextFormField(
                controller: _enderecoCtrl,
                decoration: const InputDecoration(
                  labelText: 'Endereço *',
                  prefixIcon: Icon(Icons.home_outlined),
                ),
                textCapitalization: TextCapitalization.words,
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Informe o endereço' : null,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _bairroCtrl,
                decoration: const InputDecoration(
                  labelText: 'Bairro *',
                  prefixIcon: Icon(Icons.map_outlined),
                ),
                textCapitalization: TextCapitalization.words,
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Informe o bairro' : null,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _cidadeCtrl,
                decoration: const InputDecoration(
                  labelText: 'Cidade *',
                  prefixIcon: Icon(Icons.location_city_outlined),
                ),
                textCapitalization: TextCapitalization.words,
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Informe a cidade' : null,
              ),
              const SizedBox(height: 16),

              const _SectionTitle('Serviço e agenda'),
              DropdownButtonFormField<String>(
                value: _servicoSelecionado,
                items: _servicos
                    .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                    .toList(),
                onChanged: (v) => setState(() => _servicoSelecionado = v),
                decoration: const InputDecoration(
                  labelText: 'Tipo de serviço *',
                  prefixIcon: Icon(Icons.local_florist_outlined),
                ),
                validator: (v) =>
                    v == null ? 'Selecione o tipo de serviço' : null,
              ),
              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _selecionarData,
                      icon: const Icon(Icons.calendar_today_outlined),
                      label: Text(
                        _dataPreferida == null
                            ? 'Data preferida'
                            : DateFormat('dd/MM/yyyy').format(_dataPreferida!),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _selecionarHora,
                      icon: const Icon(Icons.access_time_outlined),
                      label: Text(
                        _horaPreferida == null
                            ? 'Horário preferido'
                            : _horaPreferida!.format(context).padLeft(5, '0'),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              const _SectionTitle('Observações'),
              TextFormField(
                controller: _observacoesCtrl,
                decoration: const InputDecoration(
                  hintText:
                      'Ex.: altura da grama, acesso pelo portão lateral, pet no quintal…',
                  alignLabelWithHint: true,
                  prefixIcon: Icon(Icons.notes_outlined),
                ),
                maxLines: 4,
                textCapitalization: TextCapitalization.sentences,
              ),
              const SizedBox(height: 12),

              // >>> CORREÇÃO AQUI: ícone compatível
              SwitchListTile.adaptive(
  value: _aceitaOrcamentoWhats,
  onChanged: (v) => setState(() => _aceitaOrcamentoWhats = v),
  title: const Text('Aceito orçamento e contato por WhatsApp'),
  subtitle: const Text('Você receberá o retorno no seu Whats'),
  // Ícone compatível com o Material (corrigido)
  secondary: const Icon(Icons.chat_outlined),
),
              const SizedBox(height: 20),

              FilledButton.icon(
                onPressed: _enviarWhatsApp,
                icon: const Icon(Icons.send_rounded),
                label: const Text('ENVIAR SOLICITAÇÃO PELO WHATSAPP'),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
              ),
              const SizedBox(height: 24),
              const _Footer(),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        text,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w700,
            ),
      ),
    );
  }
}

class _Footer extends StatelessWidget {
  const _Footer();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Jardim App • Solicite seu serviço em segundos',
        style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.outline,
            ),
        textAlign: TextAlign.center,
      ),
    );
  }
}